package com.capgemini.fms.service;

import java.util.List;

import com.capgemini.fms.model.Actor;
import com.capgemini.fms.model.Film;

public interface FilmService {

	public String addFilm(Film film);

	public String modifyFilm(Film film);

	public String deleteFilm(Film film);

	public List<Film> searchFilmByTitle(String title);

	public List<Film> searchFilmByCategory(String category);

	public List<Film> searchFilmByRating(short rating);

	public List<Film> searchFilmByLanguage(String lang);

	public List<Film> searchFilmByActor(Actor actor);

	public List<Film> searchFilmByRealeaseYear(short year);

}
