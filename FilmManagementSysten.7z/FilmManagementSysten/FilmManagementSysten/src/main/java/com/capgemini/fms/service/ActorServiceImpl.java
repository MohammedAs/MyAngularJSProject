package com.capgemini.fms.service;

import java.util.List;

import com.capgemini.fms.model.Actor;
import com.capgemini.fms.repository.ActorRepository;

public class ActorServiceImpl implements ActorService {

	private ActorRepository actorRepository;

	public ActorServiceImpl(ActorRepository actorRepository) {
		super();
		this.actorRepository = actorRepository;
	}

	public String addActor(Actor actor) {
		
		if (actor == null) {
			throw new NullPointerException();
		} else {

			if (actor.getFirstName() == null || actor.getLastName() == null)
				throw new IllegalArgumentException();

			if (actor.getAlbum() == null)
				throw new IllegalArgumentException();
			
			if (actor.getFilms() == null)
				throw new IllegalArgumentException();
			
			if (actor.getGender() == null)
				throw new IllegalArgumentException();

			if (actor.getDeleteDate() == null)
				throw new IllegalArgumentException();

			if (actor.getCreateDate() == null)
				throw new IllegalArgumentException();
			
			try {
				actorRepository.save(actor);
				return "successfull";
			} catch (Exception e) {
				return "failed";
			}
		}

	}

	public List<Actor> searchByName(String firstName, String lastName) {
		List<Actor> actor = null;
		if (firstName == null || lastName == null)
			throw new NullPointerException();
		
		try {
			actor = actorRepository.searchByName(firstName, lastName);
		} catch (Exception e) {
			return null;
		}

		if (actor.isEmpty()) {
			return null;
		}
		return actor;
	}

	public List<Actor> searchByGender(String gender) {
		List<Actor> actor = null;
		
		if (gender == null) {
			throw new NullPointerException();
		}
		
		try {
			actor = actorRepository.searchByGender(gender);

		} catch (Exception e) {
			return null;
		}

		if (actor.isEmpty()) {
			return null;
		}
		return actor;
	}

	public String modifyActor(Actor actor) {
		if (actor == null) {
			throw new NullPointerException();
		}
		try {
			if (actorRepository.modifyActor(actor)) {
				return "succesfull";
			}
		} catch (Exception e) {
			return "failed";
		}
		return "failed";
	}

	public String deleteActor(String firstName, String lastName) {
		if (firstName == null || lastName == null) {
			throw new NullPointerException();
		}
		try {
			if (actorRepository.deleteActor(firstName, lastName))
				return "succesfull";

			return "falied";
		} catch (Exception e) {

			return "System Error";
		}

	}



}
