package com.capgemini.fms.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.capgemini.fms.model.Actor;
import com.capgemini.fms.model.Film;

public class FilmRepositoryImpl implements FilmRepository {

	private EntityManager em;

	public FilmRepositoryImpl(EntityManager em) {
		this.em = em;
	}

	public Boolean save(Film film) {

		try {
			TypedQuery<Film> query = em.createQuery("Select a from Film a where a.title like :nam", Film.class);
			Film filmQuery = query.setParameter("nam", film.getTitle()).getSingleResult();

			if (filmQuery == null) {
				em.persist(film);
				return true;
			} else
				return false;
		} catch (NoResultException e) {
			return false;
		}

	}

	public Boolean modifyFilm(Film film) {

		try {
			Film saveFilm = em.find(Film.class, film.getId());
			saveFilm.setDescription(film.getDescription());
			saveFilm.setRating(film.getRating());
			saveFilm.setReleaseYear(film.getReleaseYear());
			saveFilm.setLength(film.getLength());
			saveFilm.setCreateDate(film.getCreateDate());
			saveFilm.setAlbum(film.getAlbum());
			saveFilm.setTitle(film.getTitle());
			saveFilm.setLanguage(film.getLanguage());
			saveFilm.setActor(film.getActor());
			saveFilm.setCategory(film.getCategory());
			em.persist(saveFilm);
			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public Boolean deleteFilm(Film film) {

		try {
			List<Film> filmList = searchFilmByTitle(film.getTitle());
			for (Film tempFilm : filmList) {

				tempFilm.setDeleteDate(new Date());
				em.persist(tempFilm);

				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public List<Film> searchFilmByTitle(String title) {

		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.title =:t", Film.class);
			List<Film> titleList = query.setParameter("t", title).getResultList();
			return titleList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<Film> searchFilmByCategory(String category) {
		return null;
	}

	public List<Film> searchFilmByRating(short rating) {

		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.rating =:r", Film.class);
			List<Film> list = query.setParameter("r", rating).getResultList();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<Film> searchFilmByLanguage(String language) {

		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.language =:lang", Film.class);
			List<Film> list = query.setParameter("lang", language).getResultList();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<Film> searchFilmByActor(Actor actor) {

		try {
			TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName LIKE :nam", Actor.class);
			Actor tempActor = query.setParameter("nam", actor).getSingleResult();

			List<Film> filmList = new ArrayList();
			for (Film film : tempActor.getFilms()) {

				filmList.add(film);
			}

			return filmList;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<Film> searchFilmByRealeaseYear(short year) {

		try {
			TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.releaseYear =:y", Film.class);
			List<Film> list = query.setParameter("y", year).getResultList();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
