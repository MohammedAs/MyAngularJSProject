package com.capgemini.fms.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.capgemini.fms.model.Actor;

public class ActorRepositoryImpl implements ActorRepository {

	private EntityManager em;

	public ActorRepositoryImpl(EntityManager em) {
		this.em = em;
	}

	public boolean save(Actor actor) {

		try {
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a where a.firstName like :nam", Actor.class);
			Actor ac = query.setParameter("nam", actor.getFirstName()).getSingleResult();

			if (ac == null) {
				em.persist(actor);
				return true;
			} else
				return false;
		} catch (NoResultException e) {
			return false;
		}

	}

	public List<Actor> searchByName(String firstName, String lastName) {

		TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l",
				Actor.class);
		List<Actor> nameList = query.setParameter("f", firstName).setParameter("l", lastName).getResultList();
		return nameList;

	}

	public List<Actor> searchByGender(String gender) {

		TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.gender =:g", Actor.class);
		List<Actor> genderList = query.setParameter("g", gender).getResultList();
		return genderList;

	}

	public boolean deleteActor(String firstName, String lastName) {

		try {
			TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l",
					Actor.class);
			Actor actor = query.setParameter("f", firstName).setParameter("l", lastName).getSingleResult();
			actor.setDeleteDate(new Date());
			em.persist(actor);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public boolean modifyActor(Actor actor) {

		Actor savedActor = em.find(Actor.class, actor.getId());
		savedActor.setAlbum(actor.getAlbum());
		savedActor.setFirstName(actor.getFirstName());
		savedActor.setLastName(actor.getLastName());
		savedActor.setGender(actor.getGender());
		savedActor.setCreateDate(actor.getCreateDate());
		savedActor.setFilms(actor.getFilms());
		em.persist(actor);
		return true;

	}

}
