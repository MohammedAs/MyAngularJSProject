package com.capgemini.fms.repository;

import java.util.List;

import com.capgemini.fms.model.Actor;

public interface ActorRepository {

	public boolean save(Actor actor);

	public boolean deleteActor(String firstName, String lastName);

	public boolean modifyActor(Actor actor);   

	public List<Actor> searchByName(String firstName, String lastName);

	public List<Actor> searchByGender(String Gender);
}
