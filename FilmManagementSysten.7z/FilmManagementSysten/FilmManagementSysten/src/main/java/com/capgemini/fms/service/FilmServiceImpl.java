package com.capgemini.fms.service;

import java.util.List;

import com.capgemini.fms.model.Actor;
import com.capgemini.fms.model.Film;
import com.capgemini.fms.repository.FilmRepository;

public class FilmServiceImpl implements FilmService {

	private FilmRepository filmRepository;

	public FilmServiceImpl() {
		super();
	}

	public FilmServiceImpl(FilmRepository filmRepository) {
		super();
		this.filmRepository = filmRepository;
	}

	public String addFilm(Film film) {
		if (film == null) {
			throw new NullPointerException();
		} else {

			if (film.getTitle() == null)
				throw new IllegalArgumentException();
			if (film.getDescription() == null)
				throw new IllegalArgumentException();
			if (film.getReleaseYear() == 0)
				throw new IllegalArgumentException();
			if (film.getAlbum() == null)
				throw new IllegalArgumentException();
			if (film.getLanguage() == null)
				throw new IllegalArgumentException();
			if (film.getActor() == null)
				throw new IllegalArgumentException();
			if (film.getCategory() == null)
				throw new IllegalArgumentException();
			if (film.getRating() < 1 || film.getRating() > 5)
				throw new IllegalArgumentException();
			if (film.getDeleteDate() == null)
				throw new IllegalArgumentException();
			if (film.getLength() < 0)
				throw new IllegalArgumentException();
			if (film.getCreateDate() == null)
				throw new IllegalArgumentException();
			try {
				filmRepository.save(film);
				return "successfull";
			} catch (Exception e) {
				return "fail";
			}
		}

	}

	public String modifyFilm(Film film) {
		if (film == null) {
			throw new NullPointerException();
		}
		try {
			if (filmRepository.modifyFilm(film)) {
				return "succesfull";
			}
		} catch (Exception e) {
			return "failed";
		}
		return "failed";
	}

	public String deleteFilm(Film film) {
		if (film == null) {
			throw new NullPointerException();
		}
		try {
			if (filmRepository.deleteFilm(film))
				return "succesfull";
			else
				return "falied";
		} catch (Exception e) {
			return "System Error";
		}

	}

	public List<Film> searchFilmByTitle(String title) {
		List<Film> film = null;
		if (title == null) {
			throw new NullPointerException();
		}
		try {
			film = filmRepository.searchFilmByTitle(title);

		} catch (Exception e) {
			return null;
		}

		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByCategory(String category) {
		List<Film> film = null;
		if (category == null) {
			throw new NullPointerException();
		}
		try {
			film = filmRepository.searchFilmByCategory(category);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByRating(short rating) {
		List<Film> film = null;
		if (rating == 0 || rating > 5 ) {
			throw new IllegalArgumentException();
		}
		try {
			film = filmRepository.searchFilmByRating(rating);
		} catch (Exception e) {

		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByLanguage(String lang) {
		List<Film> film = null;
		if (lang == null) {
			throw new NullPointerException();
		}
		try {
			film = filmRepository.searchFilmByLanguage(lang);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByActor(Actor actor) {
		List<Film> film = null;
		if (actor == null) {
			throw new NullPointerException();
		}
		try {
			film = filmRepository.searchFilmByActor(actor);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

	public List<Film> searchFilmByRealeaseYear(short year) {
		List<Film> film = null;
		if (year == 0) {
			throw new IllegalArgumentException();
		}
		try {
			film = filmRepository.searchFilmByRealeaseYear((short) year);
		} catch (Exception e) {
		}
		if (film.isEmpty()) {
			return null;
		}
		return film;
	}

}
