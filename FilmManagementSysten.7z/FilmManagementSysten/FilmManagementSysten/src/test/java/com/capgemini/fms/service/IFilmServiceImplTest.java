package com.capgemini.fms.service;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.fms.model.Actor;
import com.capgemini.fms.model.Album;
import com.capgemini.fms.model.Category;
import com.capgemini.fms.model.Film;
import com.capgemini.fms.repository.FilmRepository;

public class IFilmServiceImplTest {

	private FilmServiceImpl filmService;

	@Mock
	private FilmRepository filmrepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		filmService = new FilmServiceImpl(filmrepository);
	}

	@Test
	public void isValidDataFilm() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("description");
		film.setLanguage("hindi");
		film.setLength((short) 120);
		film.setRating((byte) 5);
		film.setReleaseYear((short) 2016);
		film.setTitle("Fitoor");

		Mockito.when(filmrepository.save(film)).thenReturn(true);

		assertEquals("successfull", filmService.addFilm(film));
	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemError() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("description");
		film.setLanguage("hindi");
		film.setLength((short) 120);
		film.setRating((byte) 5);
		film.setReleaseYear((short) 2016);
		film.setTitle("Fitoor");

		Mockito.when(filmrepository.save(film)).thenThrow(new SQLException());

		filmService.addFilm(film);
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void isInvalidDataFilm() {
		Film film = new Film();
		film.setId(1);
		film.setActor(new ArrayList<Actor>());
		film.setAlbum(new Album());
		film.setCategory(new ArrayList<Category>());
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setDescription("description");
		film.setLanguage("hindi");
		film.setLength((short) 120);
		film.setRating((byte) 8);
		film.setReleaseYear((short) 2016);
		film.setTitle("Fitoor");

		Mockito.when(filmrepository.save(film)).thenReturn(false);

		filmService.addFilm(film);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void isNullDataFilm() {
		Film film = null;

		Mockito.when(filmrepository.save(film)).thenReturn(false);

		filmService.addFilm(film);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNull() {
		Film film = null;
		filmService.modifyFilm(film);
	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInModifyFilm() {
		Film film = new Film(2);
		Mockito.when(filmrepository.modifyFilm(film)).thenThrow(new SQLException());
		filmService.modifyFilm(film);
	}

	@Test
	public void dataIsNotPresent() {
		Film film = new Film(2);
		Mockito.when(filmrepository.modifyFilm(film)).thenReturn(false);
		assertEquals("failed", filmService.modifyFilm(film));
	}

	@Test
	public void ifDataIsPresent() {
		Film film = new Film(1);
		Mockito.when(filmrepository.deleteFilm(film)).thenReturn(true);
		assertEquals("succesfull", filmService.deleteFilm(film));

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNullDelele() {
		Film film = null;
		Mockito.when(filmrepository.deleteFilm(film)).thenReturn(false);
		filmService.deleteFilm(film);
	}

	@Test
	public void dataIsNotPresentDelele() {
		Film film = new Film(2);
		Mockito.when(filmrepository.deleteFilm(film)).thenReturn(false);
		assertEquals("failed", filmService.modifyFilm(film));
	}

	@Test
	public void ifDataIsPresentDelele() {
		Film film = new Film(1);
		Mockito.when(filmrepository.deleteFilm(film)).thenReturn(true);
		assertEquals("succesfull", filmService.deleteFilm(film));

	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInDeleteFilm() {
		Film film = new Film(2);
		Mockito.when(filmrepository.deleteFilm(film)).thenThrow(new SQLException());
		filmService.deleteFilm(film);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByTitleInputNull() {
		filmService.searchFilmByTitle(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByTilteInputNotPresent() {

		Mockito.when(filmrepository.searchFilmByTitle("Fitoor")).thenReturn(null);
		filmService.searchFilmByTitle("Fitoor");

	}

	@Test
	public void findByTitleIfInputPresent() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Mockito.when(filmrepository.searchFilmByTitle("Fitoor")).thenReturn(list);
		assertFalse(filmService.searchFilmByTitle("Fitoor").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByTitleIfSystemError() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Mockito.when(filmrepository.searchFilmByTitle("Fitoor")).thenThrow(new SQLException());
		filmService.searchFilmByTitle("Fitoor");

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByCategoryInputNull() {
		filmService.searchFilmByCategory(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByCategoryInputNotPresent() {

		Mockito.when(filmrepository.searchFilmByCategory("Comedy")).thenReturn(null);
		filmService.searchFilmByCategory("Comedy");

	}

	@Test
	public void findByCategoryIfInputPresent() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Mockito.when(filmrepository.searchFilmByCategory("Fitoor")).thenReturn(list);
		assertFalse(filmService.searchFilmByCategory("Fitoor").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByCategoryIfSystemError() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Mockito.when(filmrepository.searchFilmByCategory("Fitoor")).thenThrow(new SQLException());
		filmService.searchFilmByCategory("Fitoor");

	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void findByRatingInputNull() {
		filmService.searchFilmByRating((short) 0);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByRatingInputNotPresent() {

		Mockito.when(filmrepository.searchFilmByRating((short) 3)).thenReturn(null);
		filmService.searchFilmByRating((short) 3);

	}

	@Test
	public void findByRatingIfInputPresent() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Mockito.when(filmrepository.searchFilmByRating((short) 3)).thenReturn(list);
		assertFalse(filmService.searchFilmByRating((short) 3).isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByRatingIfSystemError() {

		Mockito.when(filmrepository.searchFilmByRating((short) 3)).thenThrow(new SQLException());
		filmService.searchFilmByRating((short) 3);

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByLanguageInputNull() {
		filmService.searchFilmByLanguage(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByLanguageInputNotPresent() {

		Mockito.when(filmrepository.searchFilmByLanguage("Hindi")).thenReturn(null);
		filmService.searchFilmByLanguage("Hindi");

	}

	@Test
	public void findByLanguageIfInputPresent() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Mockito.when(filmrepository.searchFilmByLanguage("Hindi")).thenReturn(list);

		assertFalse(filmService.searchFilmByLanguage("Hindi").isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByLanguageIfSystemError() {

		Mockito.when(filmrepository.searchFilmByLanguage("Hindi")).thenThrow(new SQLException());
		filmService.searchFilmByLanguage("Hindi");

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByActorInputNull() {
		filmService.searchFilmByActor(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByActorInputNotPresent() {

		Mockito.when(filmrepository.searchFilmByActor(null)).thenReturn(null);
		filmService.searchFilmByActor(null);

	}

	@Test
	public void findByActorIfInputPresent() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Actor a = new Actor();
		Mockito.when(filmrepository.searchFilmByActor(a)).thenReturn(list);
		assertFalse(filmService.searchFilmByActor(a).isEmpty());

	}

	@Test(expected = java.lang.Exception.class)
	public void findByActorIfSystemerror() {
		Actor actor = new Actor();
		Mockito.when(filmrepository.searchFilmByActor(actor)).thenThrow(new SQLException());
		filmService.searchFilmByActor(actor);

	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void findByRealeaseYearInputNull() {
		filmService.searchFilmByRating((short) 0);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByRealeaseYearInputNotPresent() {

		Mockito.when(filmrepository.searchFilmByRating((short) 3)).thenReturn(null);
		filmService.searchFilmByRating((short) 3);

	}

	@Test(expected = java.lang.Exception.class)
	public void findByRealeaseYearIfSystemError() {

		Mockito.when(filmrepository.searchFilmByRating((short) 3)).thenThrow(new SQLException());
		filmService.searchFilmByRating((short) 3);

	}

	@Test
	public void findByRealeaseYearIfInputPresent() {
		List<Film> list = new ArrayList<Film>();
		list.add(new Film());
		Mockito.when(filmrepository.searchFilmByRealeaseYear((short) 2016)).thenReturn(list);

		assertFalse(filmService.searchFilmByRealeaseYear((short) 2016).isEmpty());

	}

}
