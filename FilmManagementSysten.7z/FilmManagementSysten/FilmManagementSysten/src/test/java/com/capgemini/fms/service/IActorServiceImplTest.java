package com.capgemini.fms.service;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.fms.model.Actor;
import com.capgemini.fms.model.Album;
import com.capgemini.fms.model.Film;
import com.capgemini.fms.repository.ActorRepository;

public class IActorServiceImplTest {

	private ActorService actorService;

	@Mock
	private ActorRepository actorRespository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		actorService = new ActorServiceImpl(actorRespository);
	}

	@Test
	public void validParametersWhileAddingActor() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName("Amir");
		actor.setLastName("Khan");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(actorRespository.save(actor)).thenReturn(true);
		assertEquals("successfull", actorService.addActor(actor));
	}

	@Test(expected = java.lang.Exception.class)
	public void systemErrorWhileAddingActor() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName("Amir");
		actor.setLastName("Khan");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(actorRespository.save(actor)).thenThrow(new SQLException());
		actorService.addActor(actor);
		
	}

	@Test(expected = java.lang.Exception.class)
	public void invalidParameterWhileAddingActor() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName(null);
		actor.setLastName("khan");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(actorRespository.save(actor)).thenReturn(false);
		actorService.addActor(actor);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void whenActorIsNull() {
		Actor actor = null;
		Mockito.when(actorRespository.save(actor)).thenReturn(false);
		actorService.addActor(actor);
	}

	//actor is null
	@Test(expected = java.lang.NullPointerException.class)
	public void whileModifyingActorInputIsActor() {
		Actor actor = null;
		actorService.modifyActor(actor);
		Mockito.when(actorRespository.modifyActor(actor)).thenReturn(false);
		assertEquals("fail", actorService.modifyActor(actor));  
	
	}

	@Test(expected = java.lang.Exception.class)
	public void systemErrorInModifyActor() {
		Actor actor = new Actor(2);
		Mockito.when(actorRespository.modifyActor(actor)).thenThrow(new SQLException());
		actorService.modifyActor(actor);
	}

	@Test
	public void dataIsNotPresent() {
		Actor actor = new Actor(2);
		Mockito.when(actorRespository.modifyActor(actor)).thenReturn(false);
		assertEquals("failed", actorService.modifyActor(actor));
	}

	@Test
	public void ifDataIsPresent() {
		Actor actor = new Actor(1);
		actor.setFirstName("salman");
		actor.setLastName("khan");
		Mockito.when(actorRespository.deleteActor(actor.getFirstName(), actor.getLastName())).thenReturn(true);
		assertEquals("succesfull", actorService.deleteActor("salman","khan"));

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNullDelele() {
		Actor actor = null;
		Mockito.when(actorRespository.deleteActor(actor.getFirstName(), actor.getLastName())).thenReturn(false);
		actorService.deleteActor("salman","khan");
	}

	@Test
	public void dataIsNotPresentForDelete() {
		Actor actor = new Actor(2);
		Mockito.when(actorRespository.deleteActor(actor.getFirstName(), actor.getLastName())).thenReturn(false);
		assertEquals("failed", actorService.modifyActor(actor));
	}

	@Test
	public void ifDataIsPresentForDelete() {
		Actor actor = new Actor(1);
		Mockito.when(actorRespository.deleteActor(actor.getFirstName(), actor.getLastName())).thenReturn(true);
		assertEquals("succesfull", actorService.deleteActor("salman","khan"));

	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInDeleteActor() {
		Actor actor = new Actor(2);
		Mockito.when(actorRespository.deleteActor(actor.getFirstName(), actor.getLastName())).thenThrow(new SQLException());
		actorService.deleteActor("salman","khan");
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void searchByGenderInputNull() {
		actorService.searchByGender(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByGenderInputNotPresent() {
		Mockito.when(actorRespository.searchByGender("male")).thenReturn(null);
		actorService.searchByGender("male");
	}

	@Test(expected = java.lang.Exception.class)
	public void searchByGenderIfSystemError() {
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(new Actor());
		Mockito.when(actorRespository.searchByGender("Sultan")).thenThrow(new SQLException());
		actorService.searchByGender("Sultan");

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void searchByNameInputNull() {
		actorService.searchByName(null, "");
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByNameInputNotPresent() {

		Mockito.when(actorRespository.searchByName("Amir", "khan")).thenReturn(null);
		actorService.searchByName("Amir", "khan");

	}

	@Test
	public void findByNameIfInputPresent() {
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(actorRespository.searchByName("Amir", "khan")).thenReturn(l);
	
	}

	@Test(expected = java.lang.Exception.class)
	public void searchByNameIfSystemError() {
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(actorRespository.searchByName("Amir", "khan")).thenThrow(new SQLException());
		actorService.searchByName("Amir", "khan");

	}

}
