package test.CG;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import pojo.Actor;
import pojo.Album;
import pojo.Film;
import repository.ActorRepository;
import service.ActorService;


public class ActorServiceTestCases {

	private ActorService service;

	@Mock
	private ActorRepository repo;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		service = new ActorService(repo);
	}
	
	
	@Test
	public void isValidDataActor() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName("salman");
		actor.setLastName("khan");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());
	

		Mockito.when(repo.save(actor)).thenReturn(true);

		assertEquals("successfull", service.addActor(actor));
	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemError() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName("salman");
		actor.setLastName("khan");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(repo.save(actor)).thenThrow(new SQLException());

		service.addActor(actor);
	}

	@Test(expected = java.lang.Exception.class )
	public void isInvalidDataActor() {
		Actor actor = new Actor();
		actor.setId(1);
		actor.setFirstName(null);
		actor.setLastName("khan");
		actor.setGender("male");
		actor.setAlbum(new Album());
		actor.setFilms(new ArrayList<Film>());
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());

		Mockito.when(repo.save(actor)).thenReturn(false);

		service.addActor(actor);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void isNullDataActor() {
		Actor actor = null;

		Mockito.when(repo.save(actor)).thenReturn(false);

		service.addActor(actor);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsActor() {
		Actor f = null;
		/*
		 * Mockito.when(repo.modifyFilm(f)).thenReturn(false);
		 * assertEquals("fail", service.modifyFilm(f));
		 */
		service.modifyActor(f);
	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInModifyActor() {
		Actor f = new Actor(2);
		Mockito.when(repo.modifyActor(f)).thenThrow(new SQLException());
		service.modifyActor(f);
	}

	@Test
	public void dataIsNotPresent() {
		Actor f = new Actor(2);
		Mockito.when(repo.modifyActor(f)).thenReturn(false);
		assertEquals("failed", service.modifyActor(f));
	}
	@Test
	public void ifDataIsPresent() {
		Actor f = new Actor(1);
		Mockito.when(repo.deleteActor(f)).thenReturn(true);
		assertEquals("succesfull", service.deleteActor(f));

	}

	@Test(expected = java.lang.NullPointerException.class)
	public void inputIsNullDelele() {
		Actor f = null;
		Mockito.when(repo.deleteActor(f)).thenReturn(false);
		service.deleteActor(f);
	}

	@Test
	public void dataIsNotPresentDelele() {
		Actor f = new Actor(2);
		Mockito.when(repo.deleteActor(f)).thenReturn(false);
		assertEquals("failed", service.modifyActor(f));
	}

	@Test
	public void ifDataIsPresentDelele() {
		Actor f = new Actor(1);
		Mockito.when(repo.deleteActor(f)).thenReturn(true);
		assertEquals("succesfull", service.deleteActor(f));

	}

	@Test(expected = java.lang.Exception.class)
	public void isSystemErrorInDeleteActor() {
		Actor f = new Actor(2);
		Mockito.when(repo.deleteActor(f)).thenThrow(new SQLException());
		service.deleteActor(f);
	}
	@Test(expected = java.lang.NullPointerException.class)
	public void searchByGenderInputNull() {
		service.searchByGender(null);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByGenderInputNotPresent() {

		Mockito.when(repo.searchByGender("abc")).thenReturn(null);
		service.searchByGender("abc");

	}

	@Test
	public void findByTitleIfInputPresent() {
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(repo.searchByGender("Sultan")).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));

	}

	@Test(expected = java.lang.Exception.class)
	public void searchByGenderIfSystemError() {
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(repo.searchByGender("Sultan")).thenThrow(new SQLException());
		service.searchByGender("Sultan");

	}
	
	

	@Test(expected = java.lang.NullPointerException.class)
	public void searchByNameInputNull() {
		service.searchByName(null,"");
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void findByNameInputNotPresent() {

		Mockito.when(repo.searchByName("salman","khan")).thenReturn(null);
		service.searchByName("salman","khan");

	}

	@Test
	public void findByNameIfInputPresent() {
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(repo.searchByName("salman","khan")).thenReturn(l);
		// assertEquals(l, fsi.searchByTitle("Sultan"));
		// assertTrue((fsi.searchByTitle("Sultan") instanceof ArrayList));

	}

	@Test(expected = java.lang.Exception.class)
	public void searchByNameIfSystemError() {
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(repo.searchByName("salman","khan")).thenThrow(new SQLException());
		service.searchByName("salman","khan");

	}

}
