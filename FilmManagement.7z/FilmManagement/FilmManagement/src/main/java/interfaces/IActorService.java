package interfaces;

import java.util.List;

import pojo.Actor;

public interface IActorService {
	String addActor(Actor actor);
	List<Actor> searchByName(String firstName,String lastName);
	List<Actor> searchByGender(String Gender);
	String deleteActor(Actor actor);
	String modifyActor(Actor actor);
	

}
