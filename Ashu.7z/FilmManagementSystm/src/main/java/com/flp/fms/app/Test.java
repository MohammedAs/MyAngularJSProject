package com.flp.fms.app;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.fms.pojo.Actor;
import com.fms.pojo.Album;
import com.fms.pojo.Category;
import com.fms.pojo.Film;
import com.fms.pojo.Image;

public class Test {

	public static void main(String[] args) {
		
	
		EntityManagerFactory emFactory= Persistence.createEntityManagerFactory("hello");
		EntityManager em=emFactory.createEntityManager();
		em.getTransaction().begin();
		
		
		Image image=new Image();
		
		Category category=new Category("horror",new Date(),null);
		//image.setId(12);
		image.setCreateDate(new Date());
		image.setDeleteDate(null);
		image.setImageUrl("http://google.co.in");
		
		List< Image> im=new ArrayList<Image>();											
		

		Album album=new Album();
		//album.setId(78);
		album.setAlbumName("vinay");
		album.setCreateDate(new Date());
		album.setDeleteDate(null);
		album.setImage(im);
		
		Actor actor=new Actor();
		actor.setFirstName("Ranbir");
		actor.setLastName("Kapoor");
		actor.setGender("MAle");
		actor.setAlbum(album);
		//actor.setId(55999);
		actor.setFilm(null);
		
		actor.setCreateDate(new Date());
		actor.setDeleteDate(new Date());
		
		
		List<Actor> act=new ArrayList<Actor>();
		act.add(actor);
		
		Film film=new Film();
		film.setTitle("Agnipath");
		film.setLanguage("Hindi");
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());
		film.setActor(act);
		film.setLength((short) 120);
		film.setRating((byte) 2);
		film.setReleaseDate(new Date());
		film.setCategory(null);
		film.setDescriptor("Comedy");
	//film.setId(5454545);
		
		
		
		
		
		em.persist(film);
		em.persist(actor);
		em.persist(image);
		em.persist(album);
		em.persist(category);
		em.getTransaction().commit();
		em.close();
		emFactory.close();

		
		
		
				
	}

}
