package com.fms.Doa;

import java.util.List;

import com.fms.pojo.Actor;

public class ActorRepositoty implements IActorDoa{

	public String addActor(Actor actor) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Actor> searchActorByName(String firstyName, String LastName) {
		// TODO Auto-generated method stub
		return null;
	}

	public String removeActor(Actor actor) {
		// TODO Auto-generated method stub
		return null;
	}

	public String modifyActor(Actor actor) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Actor> searchByAge(byte age) {
		// TODO Auto-generated method stub
		return null;
	}

}
