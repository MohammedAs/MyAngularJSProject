package com.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.fms.Doa.IActorDoa;
import com.fms.pojo.Actor;

public class ActorService implements IActorService {
	IActorDoa actorRepository;

	public ActorService(IActorDoa actorRepository) {
		this.actorRepository=actorRepository;
	}

	public String addActor(Actor actor) {
		if(actor==null){
			throw new IllegalArgumentException();
		}
		else{
			String str=actorRepository.addActor(actor);
			return str;
		}
		
	}

	public String modifyActor(Actor actor) {
		if(actor==null){
			throw new IllegalArgumentException();
		}
		else{
			String str=actorRepository.modifyActor(actor);
			return str;
		}
		
	}

	public String deleteActor(Actor actor) {
		if(actor==null){
			throw new IllegalArgumentException();
		}
		else{
			try{
				String str=actorRepository.removeActor(actor);
				return str;
			}
			catch(Exception e){
				return "fail";
				
			}
		}
		
	}

	public List<Actor> searchActorByName(String firstName,String lastName) {
		if(firstName==null && lastName==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Actor> list=new ArrayList<Actor>();
			list=actorRepository.searchActorByName(firstName, lastName);
			return list;
		}
		
	}

	public List<Actor> searchActorByAge(byte age) {
		if(age==0){
			throw new IllegalArgumentException();
		}
		else{
			List<Actor> list=new ArrayList<Actor>();
			list=actorRepository.searchByAge(age);
			return list;
		}
	}

	
	
	
	
	

}
