package com.fms.service;

import java.util.List;

import com.fms.Doa.FilmRepository;
import com.fms.Doa.IFilmDoa;
import com.fms.pojo.Actor;
import com.fms.pojo.Category;
import com.fms.pojo.Film;

public class FilmService implements IFilmService {
	
	IFilmDoa filmRepository;
	
	

	public FilmService(IFilmDoa filmRepository) {
		super();
		this.filmRepository = filmRepository;
	}

	
	
	public String addFilm(Film film) {
		if(film==null){
			throw new IllegalArgumentException();
		}
		else{
			
			
				String result=filmRepository.addFilm(film);
				return result;
		
		}
	}

	public String modifyFilm(Film film) {
		if(film==null){
			throw new IllegalArgumentException();
		}
		else{
			
			String str=filmRepository.modifyFilm(film);
			return str;
		}
	}

	public String deleteFilm(String title) {
		if(title==null){
			throw new IllegalArgumentException();
		}
		else{
			
			String result=filmRepository.deleteFilm(title);
			return result;
		}
	}

	public List<Film> searchFilmBytitle(String title) {
		if(title==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film=filmRepository.searchFilmBytitle(title);
			return film;
		}
		
	}

	public List<Film> searchFilmByCategory(Category category) {
		if(category==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film=filmRepository.searchFilmByCategory(category);
			return film;
		}
	}

	public List<Film> searchFilmByRating(byte rating) {
			List<Film> film=filmRepository.searchFilmByRating(rating);
			return film;
		
	}

	public List<Film> searchFilmByLanguage(String language) {
		
		if(language==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film=filmRepository.searchFilmByLanguage(language);
			return film;
		}
	}

	public List<Film> searchFilmByActor(Actor actor) {
		if(actor==null){
			throw new IllegalArgumentException();
		}
		else{
			List<Film> film=filmRepository.searchFilmByActor(actor);
			return film;
		}
	}
	

}
