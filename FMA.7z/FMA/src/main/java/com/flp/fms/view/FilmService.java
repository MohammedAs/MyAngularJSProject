package com.flp.fms.view;

public interface FilmService {

	public String addFilm(Film a);
}
