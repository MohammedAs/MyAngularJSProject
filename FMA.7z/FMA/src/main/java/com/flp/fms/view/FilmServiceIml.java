package com.flp.fms.view;

public class FilmServiceIml implements FilmService {
 
	private FilmRepo Repo;
	
	 
	public FilmServiceIml(FilmRepo repo) {
		super();
		Repo = repo;
	}


	public String addFilm(Film a) {
		
		return null;
	}

}
