package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Test {
	//@SuppressWarnings("unchecked")

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		Image image=new Image();
		Category category=new Category("Cartoon",new Date(),null);
		
		
		image.setCreateDate(new Date());
		image.setDeleteDate(new Date());
		image.setImageUrl("C:\\Users\\Public\\Pictures\\Sample Pictures\\images.jpg");
		
		List<Image> img=new ArrayList<Image>();
		img.add(image);
		
		
		Album album=new Album();
		album.setAlbumName("MyAlbum");
		album.setCreateDate(new Date());
		album.setDeleteDate(new Date());
		album.setImage(img);
		album.setId(1);
		
		Actor actor=new Actor();
        actor.setFirstName("Sid");
        actor.setLastName("Diego");
        actor.setGender("Male");
        actor.setAlbum(album);
        actor.setFilm(null);
        actor.setCreateDate(new Date());
        actor.setDeleteDate(new Date());
        
        List<Actor> act=new ArrayList<Actor>();
		act.add(actor);
      
		Film film=new Film();
		film.setTitle("Iceage");
		film.setDescription("Cartoon movie");
		film.setLanguage("English");
		film.setReleaseYear(new Date());
		film.setActor(act);
		film.setRating((byte) 5);
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());	
		film.setAlbum(album);
			
        
        em.persist(film);
        em.persist(actor);
        em.persist(image);
        em.persist(category);
        em.persist(album);
        em.getTransaction().commit();
        em.close();
        //emFactory.close();

			
			
	        
	    }

	}


