package com.flp.fms.view;

public interface FilmRepo {
	public String addFilm(Film a);

}
