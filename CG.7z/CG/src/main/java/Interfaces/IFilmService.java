package Interfaces;

import java.util.List;

import POJO.Actor;
import POJO.Category;
import POJO.Film;

public interface IFilmService {
	String addFilm(Film film);
	String modifyFilm(Film film);
	String deleteFilm(Film film);
	List<Film> searchFilmByTitle(String title);
	List<Film> searchFilmByCategory(String category);
	List<Film> searchFilmByRating(short rating);
	List<Film> searchFilmByLanguage(String lang);
	List<Film> searchFilmByActor(Actor actor);
	List<Film> searchFilmByRealeaseYear(short year);

}
