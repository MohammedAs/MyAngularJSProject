package com.capgemini.film.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.fms.pojo.Actor;
import com.capgemini.fms.pojo.Album;
import com.capgemini.fms.pojo.Film;
import com.capgemini.fms.repository.IActorRepository;
import com.capgemini.fms.service.IActorService;
import com.capgemini.fms.service.ActorServiceImpl;
import com.capgemini.fms.service.FilmServiceImpl;


public class ActorServiceTest {
	private IActorService service;
	@Mock private IActorRepository repo;
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		service = new ActorServiceImpl(repo); 
	}

	//AddActor testcases
	//1.If inputs are valid is added data in Actor.
	@Test
	public void amitabhIsAnActor(){
		List<Film> filmList=new ArrayList<Film>();
		Actor actor=new Actor(1, "amitabh", "bachhan", "male",null, new Date(),
				new Date(),filmList);
		Mockito.when(repo.save((actor))).thenReturn(actor);
		assertEquals(actor, service.addActor(actor));
	}
	
	//2. if any values is not valid then values should not be added
	@Test
	public void invalidData(){
		List<Film> filmList=new ArrayList<Film>();
		Actor actor=new Actor(1, "amitabh", "bachhan", "male",null, new Date(),
				new Date(),filmList);
		Mockito.when(repo.save((actor))).thenReturn(null);
		assertEquals(null, service.addActor(actor));
	}
	//3. Even if details are valid it does not add data because of problem in system
	@Test
	public void validDataNotStore(){
		List<Film> filmList=new ArrayList<Film>();
		Actor actor=new Actor(1, "amitabh", "bachhan", "male",null, new Date(),
				new Date(),filmList);
		Mockito.when(repo.save((actor))).thenReturn(null);
		assertEquals(null, service.addActor(actor));
	}
	
	//SearchActorByName testcases
	//1.AmitabhExistInSystem
	public void AmitabhExistsInSystem(){
		List<Film> filmList=new ArrayList<Film>();
		Actor actor = new Actor(1, "amitabh", "bachhan", "male",null, new Date(),
				new Date(),filmList);
		List<Actor> actorList=new ArrayList<Actor>();
		actorList.add(actor);
		Mockito.when(repo.searchActorByName("amitabh")).thenReturn(actorList);
		
		assertEquals(actor, service.searchActorByName("amitabh"));
	}
	//2. If name is null return exception
	@Test(expected =NullPointerException.class)
	public void nullNameThenGiveException(){
		List<Film> filmList=new ArrayList<Film>();
		Actor actor = new Actor(1, "amitabh", "bachhan", "male",null, new Date(),
				new Date(),filmList);
		//List<Film> filmList=new ArrayList<Film>();
		//filmList.add(film);
		ActorServiceImpl fs=new ActorServiceImpl(repo);
		fs.searchActorByName(null);
		
	}
	//3.Actor amitabh is not present
	@Test(expected =IllegalArgumentException.class)
	public void actorNotPresent(){
		List<Film> filmList=new ArrayList<Film>();
		Actor actor = new Actor(1, "amitabh", "bachhan", "male",null, new Date(),
				new Date(),filmList);

		/*List<Film> filmList=new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(repo.FindByTitle("sol")).thenReturn(null);
		assertEquals(null, service.findByTitle("sol"));*/
		
		ActorServiceImpl fs=new ActorServiceImpl(repo);
		fs.searchActorByName("amit");
	}
		//4.Name is valid but problem in system
		public void problemInSystem(){
			List<Film> filmList=new ArrayList<Film>();
			Actor actor = new Actor(1, "amitabh", "bachhan", "male",null, new Date(),
					new Date(),filmList);
			List<Actor> actorList=new ArrayList<Actor>();
			actorList.add(actor);
			Mockito.when(repo.searchActorByName("Amitabh")).thenReturn(null);
			
			assertEquals(null, service.searchActorByName("Amitabh"));
		}
		
		//test cases for delete actor
		//1.If input is valid , should delete the actor
		@Test
		public void deleteFilmsInputPresent()
		{
			Mockito.when(repo.remove(("Amitabh"))).thenReturn(true);
			assertEquals("Actor is delete", service.removeActor("Amitabh"));
		}
		
		//2. if actor is not present,it should throw exception
		@Test
		public void deleteFilmInputNotPresent(){
			Mockito.when(repo.remove(("Amitabh"))).thenReturn(false);
			assertEquals("Actor is not present", service.removeActor("amit"));
		}
		//3. Even if value is present , it can't delete the actor(system eroor)
		@Test(expected=Exception.class)
		public void deleteFilmSystemError(){
		Mockito.when(repo.remove("Amitabh")).thenThrow(new Exception());
		service.removeActor("Amitabh");
		}
		//4.If input is null ,it should throw nullpointerexception
		@Test(expected =NullPointerException.class)
		public void deleteFilmInputIsNull(){
			service.removeActor(null);
		}
		
		//test cases for modify film
		//1.If input is null,it should throw null pointer exception
		@Test(expected =NullPointerException.class)
		public void modifyActorInputIsNull(){
			service.modifyActor(null);
		}
		//2.when input is present but film is not present in system
		@Test
		public void modifyActorInputIsNotPresent(){
			Actor actor=new Actor();
			Mockito.when(repo.updateActor((actor))).thenReturn(false);
			assertEquals("Actor is not updated", service.modifyActor(actor));
			
		}
		//3.when film is present ,system will modify the film
		@Test
		public void modifyActorInputValidAndModifyIt(){
			Actor actor=new Actor();
			Mockito.when(repo.updateActor((actor))).thenReturn(true);
			assertEquals("Actor is updated", service.modifyActor(actor));
		}
		//4. Even if film is present , it can't modify the film(system eroor)
		@Test(expected=Exception.class)
		public void modifyActorSystemError(){
			Actor actor=new Actor();
			Mockito.when(repo.updateActor(actor)).thenThrow(new Exception());
			assertEquals("error", service.modifyActor(actor));
		}
}


