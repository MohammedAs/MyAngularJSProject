package com.capgemini.fms.repository;

import java.util.List;

import com.capgemini.fms.pojo.Actor;

public class ActorRepositoryImpl implements IActorRepository{

	public Actor save(Actor actor) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Actor> searchActorByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean remove(String name) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateActor(Actor actor) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
