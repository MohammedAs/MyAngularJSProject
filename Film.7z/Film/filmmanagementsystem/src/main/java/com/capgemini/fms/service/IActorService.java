package com.capgemini.fms.service;

import java.util.List;

import com.capgemini.fms.pojo.Actor;

public interface IActorService {
	public Actor addActor(Actor actor);
	public List<Actor> searchActorByName(String name);
	public String removeActor(String name);
	public String modifyActor(Actor actor);

}
