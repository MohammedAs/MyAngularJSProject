/**
 * Created by asbanu on 6/13/2016.
 */

var myApp=angular.module("display",[]);
