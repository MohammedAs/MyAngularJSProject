/**
 * Created by asbanu on 7/5/2016.
 */

myApp.controller("Filmlist",function ($scope,filmService) {


    function callback(obj) {
        $scope.films=obj;
        $scope.showinfo=function (film)
        {
            butt=film;

            document.getElementById("Title").value=film.title;
            document.getElementById("ReleaseYear").value=film.releaseYear;
            document.getElementById("Language").value=film.language;
            document.getElementById("Rating").value=film.rating;
            document.getElementById("Description").value=film.description;
            document.getElementById("Length").value=film.length;
            var actors=film.actors;
            console.log(actors);


        }
    }



    filmService(callback);


});

