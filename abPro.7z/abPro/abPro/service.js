/**
 * Created by asbanu on 7/5/2016.
 */


myApp.service("filmService",function ($http) {
    return function (callback) {
        $http({
            method: "GET",
            url: "data/data.json"
        }).then(function (response) {
            callback(response.data);
        }, function myError(response) {
            $scope.myWelcome = response.statusText;
        });
    }



});
