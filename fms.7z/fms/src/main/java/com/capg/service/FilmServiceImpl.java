package com.capg.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capg.pojo.Actor;
import com.capg.pojo.Film;
import com.capg.repo.FilmRepo;

public class FilmServiceImpl implements FilmService {
	
	private FilmRepo repo;
	

	public FilmServiceImpl() {
		super();
		this.repo=repo;
	}

	public Film createFilm(Film film) {
		Film film1=new Film();
		repo.save(film1);
		return film1;
	}

	public List<Film> findFilmByTitle(String title) {
		if(title==null)
		{
			throw new NullPointerException();
		}
		Film film2=new Film();
		List<Film> filmList=new ArrayList<Film>();
		filmList.add(film2);
		filmList=repo.findFilmByTitle(title);
		if(film2.getTitle()!=title)
		{
			throw new IllegalArgumentException();
		}
		return filmList;
	}

	public List<Film> findFilmByLanguage(String language) {
		if(language==null)
		{
			throw new NullPointerException();
		}
		Film film3=new Film();
		List<Film> filmListByLanguage=new ArrayList<Film>();
		filmListByLanguage.add(film3);
		filmListByLanguage=repo.findFilmByLanguage(language);
		if(film3.getLanguage()!=language)
		{
			throw new IllegalArgumentException();
		}
		return filmListByLanguage;
	}

	public List<Film> findFilmByRating(byte rating) {
		if(rating==0)
		{
			throw new NullPointerException();
		}
		Film film4=new Film();
		List<Film> filmListByRating=new ArrayList<Film>();
		filmListByRating.add(film4);
		filmListByRating=repo.findFilmByRating(rating);
		if(film4.getRating()!=rating)
		{
			throw new IllegalArgumentException();
		}
		return filmListByRating;
	}

	public List<Film> findFilmByReleaseYear(Date releaseyear) {
		if(releaseyear==null)
		{
			throw new NullPointerException();
		}
		Film film5=new Film();
		List<Film> filmListByReleaseYear=new ArrayList<Film>();
		filmListByReleaseYear.add(film5);
		filmListByReleaseYear=repo.findFilmByReleaseYear(releaseyear);
		if(film5.getReleaseYear()!=releaseyear)
		{
			throw new IllegalArgumentException();
		}
		return filmListByReleaseYear;
	}

	public String deleteFilm(String title) {
		if(title==null){
			throw new NullPointerException();
		}
		else{
			try{
				if(repo.remove(title)){
					return "Film is removed..!!";
				}
				else{
					return "Film is not removed...";
				}
					
			}
			catch(Exception e){
				return "Error!!";
			}
		}
	}

	public String modifyFilm(Film film) {
		if(film==null)
		{
			throw new NullPointerException();
		}
		try{
			if(repo.updateFilm(film)){
				return "Film is updated";
			}
		}
		catch(Exception e){
			return "Error";
		}
		return "Film is not updated";
	}

}
