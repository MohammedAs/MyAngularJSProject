package com.capg.service;

import java.util.Date;
import java.util.List;

import com.capg.pojo.Film;

public interface FilmService {
	
	public Film createFilm(Film film);
	public List<Film> findFilmByTitle(String title);
	public List<Film> findFilmByLanguage(String language);
	public List<Film> findFilmByRating(byte rating);
	public List<Film> findFilmByReleaseYear(Date releaseyear);
	public String deleteFilm(String title);
	public String modifyFilm(Film film);

}
