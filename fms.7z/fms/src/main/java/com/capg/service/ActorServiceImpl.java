package com.capg.service;

import java.util.ArrayList;
import java.util.List;

import com.capg.pojo.Actor;
import com.capg.repo.ActorRepo;

public class ActorServiceImpl implements ActorService {
	
	public ActorRepo repo;
	
	public ActorServiceImpl() {
		super();
		this.repo=repo;
	}
	
	

	public ActorServiceImpl(ActorRepo repo) {
		super();
		this.repo = repo;
	}



	public Actor createActor(Actor actor) {
		Actor actor1=new Actor();
		actor1=repo.save(actor);
		return actor1;
	}

	public List<Actor> findActorByName(String name) {
		if(name==null)
		{
			throw new NullPointerException();
		}
		Actor actor2=new Actor();
		List<Actor> actorList=new ArrayList<Actor>();
		actorList.add(actor2);
		actorList=repo.findActorByName(name);
		if(actor2.getFirstName()!=name)
		{
			throw new IllegalArgumentException();
		}
		return actorList;
	}

	public String deleteActor(String name) {
		if(name==null){
			throw new NullPointerException();
		}
		else{
			try{
				if(repo.remove(name)){
					return "Actor is removed..!!";
				}
				else{
					return "Actor is not removed...";
				}
					
			}
			catch(Exception e){
				return "Error!!";
			}
		}
		
	}

	public String modifyActor(Actor actor) {
		if(actor==null)
		{
			throw new NullPointerException();
		}
		try{
			if(repo.updateActor(actor)){
				return "Actor is updated";
			}
		}
		catch(Exception e){
			return "Error";
		}
		return "Actor is not updated";
	}

}
