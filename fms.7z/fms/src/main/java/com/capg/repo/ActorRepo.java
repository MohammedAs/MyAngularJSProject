package com.capg.repo;

import java.util.List;

import com.capg.pojo.Actor;

public interface ActorRepo {
	
	public Actor save(Actor actor);
	public List<Actor> findActorByName(String name);
	public boolean remove(String name);
	public boolean updateActor(Actor actor);

}
