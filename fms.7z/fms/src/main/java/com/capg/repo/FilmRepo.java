package com.capg.repo;

import java.util.Date;
import java.util.List;

import com.capg.pojo.Film;

public interface FilmRepo {

	public Film save(Film film);
	public List<Film> findFilmByTitle(String Title);
	public List<Film> findFilmByLanguage(String language);
	public List<Film> findFilmByRating(byte rating);
	public List<Film> findFilmByReleaseYear(Date releaseYear);
	public boolean remove(String title);
	public boolean updateFilm(Film film);
}
