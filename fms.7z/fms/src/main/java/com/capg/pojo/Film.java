package com.capg.pojo;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Film {

	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	String title;
	String description;
	Date releaseYear;
	@OneToOne
	Album album;
	String language;
	@ManyToMany
	List<Actor> actor;
	@ManyToMany
	List<Category> category;
	byte rating;
	Date createDate;
	Date deleteDate;
	short length;
	public Film() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Film( String title, String description, Date releaseYear, Album album, String language,
			List<Actor> actor, List<Category> category, byte rating, Date createDate, Date deleteDate, short length) {
		super();
	
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.album = album;
		this.language = language;
		this.actor = actor;
		this.category = category;
		this.rating = rating;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		this.length = length;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public List<Actor> getActor() {
		return actor;
	}
	public void setActor(List<Actor> actor) {
		this.actor = actor;
	}
	public List<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	public byte getRating() {
		return rating;
	}
	public void setRating(byte rating) {
		this.rating = rating;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	public short getLength() {
		return length;
	}
	public void setLength(short length) {
		this.length = length;
	}
	@Override
	public String toString() {
		return "Film [id=" + id + ", title=" + title + ", description=" + description + ", releaseYear=" + releaseYear
				+ ", album=" + album + ", language=" + language + ", actor=" + actor + ", category=" + category
				+ ", rating=" + rating + ", createDate=" + createDate + ", deleteDate=" + deleteDate + ", length="
				+ length + "]";
	}
	
	
	
}







