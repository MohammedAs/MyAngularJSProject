package com.capg.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
	
	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		Image image=new Image();
		image.setCreateDate(new Date());
		image.setDeleteDate(new Date());
		image.setImageUrl("C:\\FINTECH\\sultan.jpg");
		
		List<Image> img=new ArrayList<Image>();
		img.add(image);
		
		Album album=new Album();
		album.setAlbumName("MyAlbum");
		album.setCreateDate(new Date());
		album.setDeleteDate(new Date());
		album.setImage(img);
		
		
		Actor actor=new Actor();
        actor.setFirstName("Salman");
        actor.setLastName("Khan");
        actor.setGender("Male");
        actor.setAlbum(album);
        actor.setCreateDate(new Date());
        actor.setDeleteDate(new Date());
        actor.setFilm(null);
        
        List<Actor> act=new ArrayList<Actor>();
		act.add(actor);
		
		
		Category category=new Category("Comedy",null,new Date(),new Date());
		
		
		Film film=new Film();
		film.setTitle("Sultan");
		film.setDescription("Comedy");
		film.setLanguage("Hindi");
		film.setReleaseYear(new Date());
		film.setActor(act);
		film.setRating((byte) 5);
		film.setCreateDate(new Date());
		film.setDeleteDate(new Date());	
		film.setAlbum(album);
		
		
		em.persist(actor);
		em.persist(album);
		em.persist(category);
		em.persist(film); 
        em.persist(image);
        
        
        em.getTransaction().commit();
        em.close();


		
	}

}
