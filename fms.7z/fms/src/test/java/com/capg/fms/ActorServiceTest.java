package com.capg.fms;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capg.pojo.Actor;
import com.capg.pojo.Film;
import com.capg.repo.ActorRepo;
import com.capg.service.ActorService;
import com.capg.service.ActorServiceImpl;

public class ActorServiceTest {
	
	private ActorService service;
	@Mock private ActorRepo repo;
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		service = new ActorServiceImpl(repo);
	}
	
	//Add Actor TestCases
	//1. If inputs are valid, then data is added in Actor
	@Test
	public void amitabhIsAnActor(){
		List<Film> filmList=new ArrayList<Film>();
		Actor actor=new Actor("amitabh", "bachhan", "male",null, new Date(),
				new Date(),filmList);
		Mockito.when(repo.save((actor))).thenReturn(actor);
		assertEquals(actor.getFirstName(), service.createActor(actor).getFirstName());
	}
	

}
