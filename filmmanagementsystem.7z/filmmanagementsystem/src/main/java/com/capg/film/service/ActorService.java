package com.capg.film.service;

import java.util.List;

import com.capg.film.pojo.Actor;

public interface ActorService {
	public Actor createActor(Actor actor);
	public List<Actor> findActorByName(String name);
	public String deleteActor(String name);
	public String modifyActor(Actor actor);

}
