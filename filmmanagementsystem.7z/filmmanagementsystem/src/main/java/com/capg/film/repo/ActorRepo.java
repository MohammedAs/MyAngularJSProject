package com.capg.film.repo;

import java.util.List;

import com.capg.film.pojo.Actor;
import com.capg.film.pojo.Film;

public interface ActorRepo {
	public Actor save(Actor actor);
	public List<Actor> findActorByName(String name);
	public boolean remove(String name);
	public boolean updateActor(Actor actor);

}
