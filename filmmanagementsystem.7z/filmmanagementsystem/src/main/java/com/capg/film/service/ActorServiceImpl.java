package com.capg.film.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.capg.film.pojo.Actor;
import com.capg.film.pojo.Film;
import com.capg.film.repo.ActorRepo;



public class ActorServiceImpl implements ActorService {

	private ActorRepo repo;
	public ActorServiceImpl(ActorRepo repo) {
		super();
		this.repo = repo;
	}

	public Actor createActor(Actor actor) 
	{
		Actor actor1 = new Actor();
		actor1=repo.save(actor);
		return actor1;
	}



		public List<Actor> findActorByName(String name) {
			if(name==null){
				throw new NullPointerException();
			}
			Actor actor2 = new Actor();
			List<Actor> actorList=new ArrayList<Actor>();
			actorList.add(actor2);
			actorList=repo.findActorByName(name);
			if(actor2.getFirstName()!=name){
				throw new IllegalArgumentException();
			}
			return actorList;
		}
		public String deleteActor(String name) {
			if(name.equals(null)){
				throw new NullPointerException();
			}
			else{
				try{
					if(repo.remove(name)){
						return "Actor is delete";
					}
						else{
							return "Actor is not present";
						}
					}catch(Exception e){
						return "erroe";
					}
				}
		}

		public String modifyActor(Actor actor) {
			if(actor==null){
				throw new NullPointerException();
			}
			else{
				try{
					if(repo.updateActor(actor)){
						return "Actor is updated";
					}
					
				}catch(Exception e){
				
				}
				return "Actor is not updated";
			}
		}


}
