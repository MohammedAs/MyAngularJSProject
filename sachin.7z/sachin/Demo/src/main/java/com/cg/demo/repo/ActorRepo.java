package com.cg.demo.repo;

import com.cg.demo.pojo.Actor;

public interface ActorRepo {

	public boolean save(Actor a);
	
	public Actor findByName(String name);
}
